Ex Kali
172.20.135.100/16

Router:
external- 172.20.135.1/16
internal- 192.168.135.1/24

Internal web:
192.168.135.2/24

Internal Kali:
192.168.135.100/24