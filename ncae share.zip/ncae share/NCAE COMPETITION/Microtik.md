microtik resources
https://help.mikrotik.com/docs/spaces/ROS/pages/328119/Getting+started



![[Pasted image 20250311192322.png]]
![[Pasted image 20250311192631.png]]![[Pasted image 20250311192704.png]]
#ether6 should be 192.160.0.0 in this case by removing the ip address with:
![[Pasted image 20250311193153.png]]
system reboot 
#to restart router